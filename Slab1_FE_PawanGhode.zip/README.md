# Slab1_FE_PawanGhode

React + Tailwind + Router + Translator + Random Generator